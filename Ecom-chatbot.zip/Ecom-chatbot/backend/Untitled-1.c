#include<stdio.h>

int main()
{
    int a,b;

    scanf("%2d%3d",&a,&b);
    printf("%d %d",a,b);
}