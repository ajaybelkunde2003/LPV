for i,j in order.items():
    #      print(f"{i}:{menu_dictionary[i]}:{j}")